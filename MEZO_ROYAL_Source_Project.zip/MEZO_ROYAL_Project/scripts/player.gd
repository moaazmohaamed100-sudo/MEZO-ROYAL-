extends CharacterBody3D

var speed := 8.0
var jump_velocity := 5.5
var gravity := 18.0
var health := 100.0
var fire_cooldown := 0.0
var jump_pressed := false
var camera: Camera3D

func _ready() -> void:
    _make_character(Color(0.15, 0.55, 0.95))
    camera = Camera3D.new()
    camera.position = Vector3(0, 5, 9)
    camera.rotation_degrees = Vector3(-22, 0, 0)
    add_child(camera)
    camera.current = true

func _make_character(color: Color) -> void:
    var mesh_instance := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.55
    capsule.height = 1.9
    mesh_instance.mesh = capsule
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mesh_instance.material_override = mat
    mesh_instance.position.y = 1.0
    add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.55
    shape.height = 1.9
    collision.shape = shape
    collision.position.y = 1.0
    add_child(collision)

func _physics_process(delta: float) -> void:
    if health <= 0:
        return
    fire_cooldown = max(0.0, fire_cooldown - delta)
    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var direction := Vector3(input_dir.x, 0, input_dir.y).normalized()
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif Input.is_action_just_pressed("jump") or jump_pressed:
        velocity.y = jump_velocity
        jump_pressed = false
    move_and_slide()
    if direction.length() > 0.1:
        rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), delta * 8.0)
    if Input.is_action_just_pressed("fire"):
        try_fire()

func try_fire() -> void:
    if fire_cooldown > 0.0 or health <= 0:
        return
    fire_cooldown = 0.35
    var space := get_world_3d().direct_space_state
    var origin := camera.global_position
    var direction := -camera.global_transform.basis.z
    var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 45.0)
    query.exclude = [self]
    var hit := space.intersect_ray(query)
    if hit and hit.collider and hit.collider.has_method("take_hit"):
        hit.collider.take_hit(34.0)
