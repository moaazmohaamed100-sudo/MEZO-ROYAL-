extends CharacterBody3D

var target: Node3D
var health := 100.0
var speed := 4.0
var gravity := 18.0
var think_timer := 0.0
var fire_timer := 0.0
var wander_dir := Vector3.FORWARD

func _ready() -> void:
    var mesh_instance := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.5
    capsule.height = 1.8
    mesh_instance.mesh = capsule
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.85, 0.28, 0.18)
    mesh_instance.material_override = mat
    mesh_instance.position.y = 0.9
    add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.5
    shape.height = 1.8
    collision.shape = shape
    collision.position.y = 0.9
    add_child(collision)

func _physics_process(delta: float) -> void:
    if health <= 0:
        queue_free()
        return
    if not is_instance_valid(target) or target.health <= 0:
        _wander(delta)
        return
    think_timer -= delta
    fire_timer -= delta
    var to_target: Vector3 = target.global_position - global_position
    var distance := to_target.length()
    if think_timer <= 0:
        think_timer = randf_range(0.5, 1.2)
        wander_dir = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized()
    if distance > 8.0:
        velocity.x = to_target.normalized().x * speed
        velocity.z = to_target.normalized().z * speed
    else:
        velocity.x = wander_dir.x * speed * 0.35
        velocity.z = wander_dir.z * speed * 0.35
        if fire_timer <= 0 and distance < 24.0:
            fire_timer = randf_range(1.0, 1.8)
            target.health = max(0.0, target.health - 7.0)
    if not is_on_floor():
        velocity.y -= gravity * delta
    move_and_slide()
    if Vector2(velocity.x, velocity.z).length() > 0.2:
        rotation.y = atan2(velocity.x, velocity.z)

func _wander(delta: float) -> void:
    think_timer -= delta
    if think_timer <= 0:
        think_timer = randf_range(1.0, 3.0)
        wander_dir = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized()
    velocity.x = wander_dir.x * speed * 0.5
    velocity.z = wander_dir.z * speed * 0.5
    if not is_on_floor():
        velocity.y -= gravity * delta
    move_and_slide()

func take_hit(amount: float) -> void:
    health = max(0.0, health - amount)
