extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const BOT_SCRIPT = preload("res://scripts/bot.gd")

var player
var bots: Array = []
var hud_label: Label
var health_label: Label
var match_over := false
var zone_radius := 44.0
var zone_timer := 0.0

func _ready() -> void:
    _make_world()
    _make_player()
    _make_bots(9)
    _make_hud()
    _make_mobile_controls()
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _process(delta: float) -> void:
    if match_over:
        return
    zone_timer += delta
    if zone_timer > 8.0:
        zone_timer = 0.0
        zone_radius = max(12.0, zone_radius - 2.0)
    _check_zone(player, delta)
    for bot in bots:
        if is_instance_valid(bot):
            _check_zone(bot, delta)
    var alive := 0
    for bot in bots:
        if is_instance_valid(bot) and bot.health > 0:
            alive += 1
    if player.health > 0 and alive == 0:
        _finish_match("فزت! أنت آخر لاعب")
    elif player.health <= 0:
        _finish_match("انتهت الجولة")

func _make_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.72, 0.78, 0.86)
    environment.ambient_light_energy = 0.8
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.1
    add_child(sun)

    _add_box("Island Ground", Vector3(0, -0.6, 0), Vector3(100, 1, 100), Color(0.22, 0.48, 0.24))
    # Simple low-poly buildings and cover.
    var building_positions = [
        Vector3(-18, 2, -12), Vector3(15, 2, -18), Vector3(20, 2, 14),
        Vector3(-22, 2, 20), Vector3(0, 2, 25), Vector3(2, 2, -28)
    ]
    for i in range(building_positions.size()):
        var p: Vector3 = building_positions[i]
        _add_box("House %d" % i, p, Vector3(9, 4, 8), Color(0.55, 0.48, 0.36))
        _add_box("Roof %d" % i, p + Vector3(0, 2.5, 0), Vector3(10, 1, 9), Color(0.32, 0.22, 0.18))
    for i in range(18):
        var x := randf_range(-42, 42)
        var z := randf_range(-42, 42)
        _add_box("Cover", Vector3(x, 0.7, z), Vector3(2.5, 1.4, 2.5), Color(0.34, 0.36, 0.31))

    # Boundary markers.
    for i in range(32):
        var angle := TAU * float(i) / 32.0
        var marker := MeshInstance3D.new()
        var mesh := CylinderMesh.new()
        mesh.top_radius = 0.15
        mesh.bottom_radius = 0.15
        mesh.height = 3.0
        marker.mesh = mesh
        marker.position = Vector3(cos(angle) * 47, 1.5, sin(angle) * 47)
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(0.9, 0.3, 0.12)
        marker.material_override = mat
        add_child(marker)

func _add_box(label: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.name = label
    body.position = pos
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    mesh_instance.material_override = material
    body.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.set_script(PLAYER_SCRIPT)
    player.name = "Player"
    player.position = Vector3(0, 2, 0)
    add_child(player)

func _make_bots(count: int) -> void:
    for i in range(count):
        var bot := CharacterBody3D.new()
        bot.set_script(BOT_SCRIPT)
        bot.name = "Bot_%02d" % i
        var angle := TAU * float(i) / float(count)
        bot.position = Vector3(cos(angle) * 25, 2, sin(angle) * 25)
        bot.target = player
        add_child(bot)
        bots.append(bot)

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(16, 16)
    panel.custom_minimum_size = Vector2(280, 88)
    layer.add_child(panel)
    var column := VBoxContainer.new()
    panel.add_child(column)
    hud_label = Label.new()
    hud_label.text = "MEZO ROYAL  |  فردي"
    column.add_child(hud_label)
    health_label = Label.new()
    health_label.text = "الصحة: 100"
    column.add_child(health_label)
    var help := Label.new()
    help.text = "WASD للحركة • Space للقفز • زر الماوس للإطلاق"
    column.add_child(help)
    var timer := Timer.new()
    timer.wait_time = 0.2
    timer.timeout.connect(_update_hud)
    timer.autostart = true
    add_child(timer)

func _make_mobile_controls() -> void:
    var layer := get_node_or_null("MobileControls")
    if layer:
        return
    var canvas := CanvasLayer.new()
    canvas.name = "MobileControls"
    add_child(canvas)
    var fire_button := Button.new()
    fire_button.text = "إطلاق"
    fire_button.position = Vector2(1080, 590)
    fire_button.size = Vector2(150, 90)
    fire_button.pressed.connect(func(): player.try_fire())
    canvas.add_child(fire_button)
    var jump_button := Button.new()
    jump_button.text = "قفز"
    jump_button.position = Vector2(920, 610)
    jump_button.size = Vector2(120, 65)
    jump_button.pressed.connect(func(): player.jump_pressed = true)
    canvas.add_child(jump_button)
    var note := Label.new()
    note.text = "تحكم الهاتف: استخدم أزرار الحركة الافتراضية أو لوحة مفاتيح للتجربة"
    note.position = Vector2(16, 650)
    canvas.add_child(note)

func _check_zone(actor, delta: float) -> void:
    if actor == null or actor.health <= 0:
        return
    var flat := Vector2(actor.global_position.x, actor.global_position.z)
    if flat.length() > zone_radius:
        actor.health = max(0, actor.health - 5.0 * delta)

func _update_hud() -> void:
    if is_instance_valid(player):
        health_label.text = "الصحة: %d  |  اللاعبون الباقون: %d" % [int(player.health), _alive_count()]
        hud_label.text = "MEZO ROYAL  |  منطقة اللعب: %d م" % int(zone_radius)

func _alive_count() -> int:
    var count := 1 if player.health > 0 else 0
    for bot in bots:
        if is_instance_valid(bot) and bot.health > 0:
            count += 1
    return count

func _finish_match(message: String) -> void:
    match_over = true
    var result := Label.new()
    result.text = message + "\nاضغط F5 لإعادة الجولة"
    result.add_theme_font_size_override("font_size", 36)
    result.position = Vector2(430, 300)
    get_node("MobileControls").add_child(result)
